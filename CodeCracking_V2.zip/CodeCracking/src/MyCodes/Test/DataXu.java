package MyCodes.Test;

public class DataXu {

	public static void main(String[] args) {
		
		int n =3;
		int [] p = {2,7,2};
		int size = p.length;
		
		sortDescending(p);		
		printArray(p);
		System.out.println("Number: "+getUmbrellasAgain(n, size, p));
		
		
	}
	
	
	static int getUmbrellasAgain(int n, int p_size, int[] p) {
		int umb =0;
		int persons = n;
		int index=0;
		int capacity =p[0];
		while (index < p_size) {
		  capacity = p[index];
		  while (persons - capacity >= 0) {			
			persons = (persons-capacity);
			umb++;
		  }
			index++;
		
		}
		
		if (persons >0){
			return -1;
		}
		
		return umb;
		
		
	}
	
	
	
	
	static int getUmbrellas(int n, int p_size, int[] p) {
		int umb =0;
		int persons = n;
		int last=0;
		for (int m=0; m< p_size; m++){
			int capacity = p[m];
			if (persons < capacity){
				return -1;
			}
			persons = (persons-capacity);
			
			if ((persons <0 )) {
				return -1;
			}
			
			umb++;
			last =p[m];
		}
		return umb;
		
		
	}
	
	 // Prints the array
   static void printArray(int arr[])
    {
        int n = arr.length;
        for (int i=0; i<n; ++i)
            System.out.print(arr[i]+" ");
        System.out.println();
    }
   
	static void sortDescending(int [] array){
    	int max;
    	for (int i = 0; i < array.length; i++)
    	{
    	    max = i;
    	    for (int j = i + 1; j < array.length; j++)
    	    {
    	        if (array[j] > array[max])
    	        {
    	            max = j;
    	        }
    	    }

    	    if (max != i)
    	    {
    	       int temp = array[i];
    	       array[i] = array[max];
    	       array[max] = temp;
    	    }
    	}
    }
}
