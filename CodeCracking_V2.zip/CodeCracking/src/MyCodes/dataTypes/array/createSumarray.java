package MyCodes.dataTypes.array;

public class createSumarray {

	public static void main(String[] args) {
		int []arr = {1,4, 7, 2, 5, 6};
		int size = arr.length;
	//	int j
		for (int i=0; i<size;i++){
			for (int j=0; j<size;j++){
				System.out.println(arr[i] +" "+arr[j]); 
			}
		}

	}

}
