package MyCodes.dataTypes.list;

public class Circle implements Comparable<Circle> {
	
public double radius;
	
	public Circle(double r) {
		this.radius = r;
	}
	
	public Circle() {
		this(1);
	}

	@Override
	public int compareTo(Circle o) {
		if (this.radius > o.radius) return 1;
		if (this.radius == o.radius) return 0;
		return -1;
	}
	
	@Override
	public String toString() {
		return "Radius: " + this.radius;
	}
	
/*	private int dia;

	public Circle(int dia1) {
		this.dia = dia1;
	}

	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		this.dia = dia;
	}*/
	
	

}
