package MyCodes.dataTypes.list;

public class DemoList {

	public static void main(String[] args) {
		
		LinkedList<Integer> integers = new LinkedList<Integer>();

		integers.addAtStart(5);
		integers.addAtStart(10);
		integers.addAtStart(2);
		integers.addAtStart(12);
		integers.addAtStart(19);
		integers.addAtStart(20);
		System.out.println(integers.length());
		System.out.println(integers.find(20));
			
		/*LinkedList<Circle> list = new LinkedList<Circle>();
		list.addHeadFirst(new Circle(5));
		list.addHeadFirst(new Circle(10));
		list.addHeadFirst(new Circle(15));
		list.addHeadFirst(new Circle(20));
		list.toString();*/

	}

}
