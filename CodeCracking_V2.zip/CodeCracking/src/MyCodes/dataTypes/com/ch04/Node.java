package MyCodes.dataTypes.com.ch04;

public class Node {
	
	int data;
	Node nextNode;
	
	public Node(int data) {
		this.data = data;
	}

}
