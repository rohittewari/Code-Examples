package MyCodes.dataTypes.com.ch04;

public class LinkedList {
	int length;
	Node head;
	
	public void addHeadFirst(int data) {
		Node newNode = new Node(data);
		newNode.nextNode = head;
		this.head = newNode;
		this.length += 1;
	}
	
	public void addLastlementsToHead(int elements){
		Node current = head;
		Node matched = null;
		Node prv= null;
		int loop =0;
		while(current.nextNode!= null) {
			loop +=1;
			System.out.println("loop: "+loop); 
			if (loop == (this.length - elements)){  //6
				prv     = current; 
				matched = current.nextNode;
			}	
			current = current.nextNode;
		}
		
		current.nextNode = this.head;
		prv.nextNode =null;		
		this.head = matched;
		
	}
	
	public void printList(){
		Node current = head;
		while(current!= null) {
			
			System.out.print(current.data + "  ");
			current = current.nextNode;
		}
		
	}
	

}
