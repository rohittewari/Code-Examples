package com.ch04;

public class Demo {

	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		list.addHeadFirst(1);
		list.addHeadFirst(2);
		list.addHeadFirst(3);
		list.addHeadFirst(4);  //matched
		
		list.addHeadFirst(5);
		list.addHeadFirst(6);
		list.addHeadFirst(7);
		list.addHeadFirst(8);
		list.addHeadFirst(9);
		list.addHeadFirst(10);
		
		list.printList();		
		list.addLastlementsToHead(4);
		System.out.println("-------");
		list.printList();
		

	}
	
	

}
