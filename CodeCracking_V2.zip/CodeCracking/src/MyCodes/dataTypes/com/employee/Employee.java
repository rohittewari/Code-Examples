package MyCodes.dataTypes.com.employee;

/**
  Write a class Employee, which represents an employee in a company. The employee has a employeeNumber (9 digit number), firstName, lastName and emailId as member variables. Create a few employee objects and store them in an array. Write the insertion sort algorithm, which takes an array of employee
   and sorts them in order of their employee number. 
 *
 */

public class Employee {
	
	public int employeeNumber;
	public String firstName;
	public String lastName;
	public String email;
	
	public Employee(int employeeNumber, String firstName, String lastName,
			String email) {
		this.employeeNumber = employeeNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}
	
	public String toString() {
		return this.employeeNumber + " : " + this.email;
	}

}
