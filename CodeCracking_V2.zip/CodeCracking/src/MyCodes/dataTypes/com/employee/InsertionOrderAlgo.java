package MyCodes.dataTypes.com.employee;

import java.util.Arrays;

public class InsertionOrderAlgo {

private Employee[] employees;
	
	public InsertionOrderAlgo(int size) {
		this.employees = new Employee[size];
	}
	
	public void sort() {
		for (int i = 0; i < employees.length; i++) {
			System.out.println("i= "+i); 
			Employee current = employees[i];
			int j = i-1;
			System.out.println("Outer J: "+j); 
			while (j >=0 && employees[j].employeeNumber >= current.employeeNumber) {
				employees[j+1] = employees[j];
				j--;
			  System.out.println("inner J: "+j); 
			}
			employees[j+1] = current;
		}
	}
	
	public static void main(String[] args) {
		InsertionOrderAlgo sorter = new InsertionOrderAlgo(4);
		Employee emp1 = new Employee(100000009, "John","Doe", "john.doe@dsnalgos.com");
		sorter.employees[0] = emp1;
		Employee emp2 = new Employee(100000002, "Patrick","Dwight", "patrick.dwight@dsnalgos.com");
		sorter.employees[1] = emp2;
		Employee emp3 = new Employee(100000011, "Marlo","Thomas", "marlo.thomas@dsnalgos.com");
		sorter.employees[2] = emp3;
		Employee emp4 = new Employee(100000004, "Barbara","Weatherspoon", "barbara.weatherspoon@dsnalgos.com");
		sorter.employees[3] = emp4;
		sorter.sort();
		System.out.println(Arrays.deepToString(sorter.employees));
	}
}
