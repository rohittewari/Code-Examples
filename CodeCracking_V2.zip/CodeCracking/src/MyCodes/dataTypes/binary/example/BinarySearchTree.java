package MyCodes.dataTypes.binary.example;

public class BinarySearchTree {

	private TreeNode root;

	public TreeNode getRoot() {
		return root;
	}

	public void setRoot(TreeNode root) {
		this.root = root;
	}

	public void addToTree(Integer data) {
		if (root == null) {
			root = new TreeNode(data);
		} else {
			TreeNode current = root;
			TreeNode parent = root;
			// TreeNode left, right =null;
			boolean isleft = false;
			while (current != null && current.getData() != data) {
				parent = current;
				if (data > current.getData()) {
					current = current.getRightNode();
					isleft = false;
				} else if (data < current.getData()) {
					current = current.getLeftNode();
					isleft = true;
				}
			}
			if (isleft)
				{ parent.setLeftNode(new TreeNode(data)); }
			else
				{ parent.setRightNode(new TreeNode(data)); }
		}
	}

	public void printInOrderTree(TreeNode node) {
		if (node != null) {
			printInOrderTree(node.getLeftNode());
			System.out.print(node.getData() + "  ");
			printInOrderTree(node.getRightNode());
		}

	}

	public static void main(String[] args) {
		BinarySearchTree bs = new BinarySearchTree();
		bs.addToTree(10);                                                   
		bs.addToTree(11);
		bs.addToTree(6);
		bs.addToTree(9);
		bs.addToTree(12);
		bs.addToTree(18);
		bs.addToTree(14);
		bs.addToTree(7);
		bs.printInOrderTree(bs.getRoot());
	}
	
	 /**
	     					10
	     		6				 11
	     			9    			12
	     		  7						18
	     							 14	
	     
	   
	     
	     6  7  9  10  11  12  14  18   - Actual
	  */
	
	
	

}
