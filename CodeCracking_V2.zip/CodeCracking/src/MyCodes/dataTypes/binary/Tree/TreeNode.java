package MyCodes.dataTypes.binary.Tree;

public class TreeNode {
	
	int data;
	TreeNode left;
	TreeNode right;
	
	public TreeNode (int d){
		this.data=d;
	}

}
