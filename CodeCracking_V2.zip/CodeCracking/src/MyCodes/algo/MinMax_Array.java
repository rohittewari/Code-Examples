package MyCodes.algo;

public class MinMax_Array {

	public static void main(String[] args) {
		int [] in = {10,20,32,4,50,6,70};
		int min = Integer.MAX_VALUE ; //in[0];
		int max = Integer.MIN_VALUE; //in[0];
		
		for (int i=0; i<in.length; i++){
			if (in[i]>max) max = in[i];
			if (in[i]<min) min = in[i];
		}
		System.out.println("Max: "+max);
		System.out.println("Min: "+min);

	}

}
