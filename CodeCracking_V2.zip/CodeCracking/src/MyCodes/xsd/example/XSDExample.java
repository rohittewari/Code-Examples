package MyCodes.xsd.example;

public class XSDExample {

}
