package MyCodes.java.features.lamda;

public class Lamda {

	public static void main(String[] args) {
		//greetingFunction = ()->{System.out.println("Hello World")};
		
		
	}

}
