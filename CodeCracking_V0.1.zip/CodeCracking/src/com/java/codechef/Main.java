package com.java.codechef;

import java.util.Scanner;

public class Main
{
	public static void main (String[] args) throws java.lang.Exception
	{
		Scanner scan=new Scanner(System.in);
		int t=scan.nextInt();
		while(t--!=0){
		   int g=scan.nextInt();
		   while(g--!=0){
		       int i,n,q;
		       i=scan.nextInt();
		       n=scan.nextInt();
		       q=scan.nextInt();
		       if(i==1){
		           if(n%2==0){
		               System.out.println(n/2);
		           }
		           else{
		               if(q==1){
		                   System.out.println((n-1)/2);
		               }
		               else{
		                   System.out.println((n+1)/2);
		               }
		           }
		       }
		       else{
		           if(n%2==0){
		               System.out.println(n/2);
		           }
		           else{
		               if(q==1){
		                   System.out.println((n+1)/2);
		               }
		               else{
		                   System.out.println((n-1)/2);
		               }
		           }
		       }
		   }
		}
	}
}
 