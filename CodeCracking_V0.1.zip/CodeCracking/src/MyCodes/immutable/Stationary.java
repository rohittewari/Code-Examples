package MyCodes.immutable;

public class Stationary {
	public Book book;

	public static void main(String[] args) {
		Stationary s = new Stationary();
		Book b = new Book("MyBook");
		
				

	}

}

final class Book {
	public final String author;	
	/*public Book() {
		
	}*/
	public Book(String auth){
		this.author = auth;
	}
	public String getAuthor() {
		return author;
	}
			
}