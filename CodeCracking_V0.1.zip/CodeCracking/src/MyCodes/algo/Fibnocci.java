package MyCodes.algo;

import java.util.LinkedList;

public class Fibnocci {

	public static void main(String[] args) {
		// 0 1 1 2 3 5 8
			
			int first = 0;
			int prev =1;
			
			LinkedList<Integer> queue = new LinkedList<Integer>();
			queue.add(prev);
				
			for (int i=0; i<101; i++){
				prev = queue.getLast();
				queue.add(first+prev);
				first = prev;
					
			}
			System.out.println(queue.toString());
		}		

	
}
