package MyCodes.dataTypes.binary.example;

public class TreeNode {
	
	public Integer data;
	public TreeNode rightNode;
	public TreeNode leftNode;
	private boolean isDeleted;
	
	public TreeNode(Integer data) {		
		this.data = data;		
	}
	
	public Integer getData() {
		return data;
	}
	public void setData(Integer data) {
		this.data = data;
	}
	public TreeNode getRightNode() {
		return rightNode;
	}
	public void setRightNode(TreeNode rightNode) {
		this.rightNode = rightNode;
	}
	public TreeNode getLeftNode() {
		return leftNode;
	}
	public void setLeftNode(TreeNode leftNode) {
		this.leftNode = leftNode;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
		

}
