package MyCodes.dataTypes.list;

public class LinkedList<T> {
	
	private Node<T> head;

	public Node<T> getHead() {
		return this.head;
	}

	public void addAtStart(T data) {
		Node<T> newNode = new Node<T>(data);
		newNode.setNextNode(this.head);
		this.head = newNode;
	}

	public Node<T> deleteAtStart() {
		Node<T> toDel = this.head;
		this.head = this.head.getNextNode();
		return toDel;
	}

	public Node<T> find(T data) {
		Node<T> curr = this.head;
		while (curr != null) {
		//	System.out.println(curr.);
			if (curr.getData().equals(data)) {
				return curr;
			}
			curr = curr.getNextNode();
		}
		return null;
	}

	public int length() {
		if (head == null)
			return 0;
		int length = 0;
		Node<T> curr = this.head;
		while (curr != null) {
			length += 1;
			curr = curr.getNextNode();
		}
		return length;
	}

	public boolean isEmpty() {
		return this.head == null;
	}
	
	/*private Node<T> node; 
	
		
	public void addHeadFirst(T data){
		
		Node<T> n1 = new Node<T>(data); 
		n1.setNextNode(this.node);
		this.node = n1;
	}
	
	public String toString(){
		Node current = this.node;
		while (current != null){
			System.out.println(((Circle)current.getData()).getDia());
			current = current.getNextNode();
		}
	  return null;
	}
*/
}
