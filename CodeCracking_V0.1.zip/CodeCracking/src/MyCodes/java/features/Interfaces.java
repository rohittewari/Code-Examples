package MyCodes.java.features;

@FunctionalInterface
public interface Interfaces {
	
	static void m1(){
		System.out.println("Hello");
	}
	static void m3(){
		System.out.println("Hello");
	}
	
	void m2();
}
