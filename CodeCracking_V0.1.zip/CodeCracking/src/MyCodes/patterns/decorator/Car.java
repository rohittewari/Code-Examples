package MyCodes.patterns.decorator;

public interface Car {
	
	public void assemble();

}


// http://www.journaldev.com/1540/decorator-design-pattern-in-java-example