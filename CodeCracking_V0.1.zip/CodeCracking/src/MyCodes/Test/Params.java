package MyCodes.Test;

public class Params {

	public static void main(String[] args) {
		
		String a = args[0];
		String b = args[1];
		String c = args[2];
				
				

	}

}
