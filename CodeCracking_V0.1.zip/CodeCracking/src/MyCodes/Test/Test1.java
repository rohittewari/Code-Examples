package MyCodes.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Test1 {
	
	public int i=5;

	void sum(int a,long b){System.out.println("a method invoked");}  
	void sum(long a,int b){System.out.println("b method invoked");}  
	  
	  public static void main(String args[]){  
	  Test1 obj=new Test1();  
	 // obj.sum(20,20);//now ambiguity  
	  
	  for(;;){
		  System.out.println("Hi");
	  }
	  }  

}

class t2 extends Test1 {
	
	 //public int i =7;
	 public static void main(String args[]){ 
		 System.out.println(new t2().i);
		 Test1 t1 = new Test1();
		 System.out.println(t1.i);		 
	 }
	
	 void iterator(){
		 ArrayList aList = null;
		 Iterator li = aList.iterator();
		 ListIterator listli =aList.listIterator();
		 
		 
		 
	 }
}
